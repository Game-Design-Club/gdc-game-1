﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    [SerializeField] float horizontalSpeed = 2f;
    [SerializeField] float verticalSpeed = 2f;
    [SerializeField] Rigidbody2D rb;
    [SerializeField] float jumpCoolDown = 1f;
    public bool isAlive = true;


    private void FixedUpdate()
    {
        if (isAlive)
        {
            ProcessInputs();
        }

        if (jumpCoolDown > Mathf.Epsilon)
        {
            jumpCoolDown -= Time.deltaTime;
        }

        
    }

    void ProcessInputs()
    {
        if (Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow))
        {
            rb.AddForce(transform.right * horizontalSpeed * Time.deltaTime); 
        }

        if (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow))
        {
            rb.AddForce(-transform.right * horizontalSpeed * Time.deltaTime);
        }

        if (Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.UpArrow))
        {
            if (jumpCoolDown <= Mathf.Epsilon)
            {
                rb.AddForce(transform.up * verticalSpeed * Time.deltaTime);
            }

            else
            {
                jumpCoolDown = 1f;
            }

        }
    }
}
