﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    [SerializeField] float horizontalSpeed = 2f;
    [SerializeField] float verticalSpeed = 2f;

    [SerializeField] Rigidbody2D rb;
    [SerializeField] float jumpCoolDown = 1f;
    public bool isAlive = true;
    public bool[] keys = {false, false, false, false};
    /*keys[0] - D
     *keys[1] - A
     *keys[2] - Space
     *keys[3] - W
     */

    private void FixedUpdate()
    {
        ProcessInputs();
        ProcessPlayerMovement();
    }

    private void ProcessInputs()
    {
        if (Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow))
        {
            keys[0] = true;
        }
        else
        {
            keys[0] = false;
        }

        if (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow))
        {
            keys[1] = true;
        }

        else
        {
            keys[1] = false;
        }

        if (Input.GetKey(KeyCode.Space) || Input.GetKey(KeyCode.UpArrow))
        {
            keys[2] = true;
        }

        else
        {
            keys[2] = false;
        }

        if (Input.GetKey(KeyCode.W))
        {
            keys[3] = true;
        }

        else
        {
            keys[3] = false;
        }
    }

    public void ProcessPlayerMovement()
   {
        if (keys[0])
        {
            print("You are pressing D");
        }

        if (keys[1])
        {
            print("You are pressing A");
        }

        if (keys[2])
        {
            //add mveme
        }

        if (keys[3])
        {
            //add mveme
        }
    }
        
}

