﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    [SerializeField] float horizontalSpeed = 10f;
    [SerializeField] float verticalSpeed = 2f;
    [SerializeField] float sprintMultiplyer = 1f;

    [SerializeField] float gravityScale = 1f;

    [SerializeField] float jumpTimer = 0.5f;

    [SerializeField] Rigidbody2D rb;

    public bool isGrounded;

    public bool isSprinting;

    public bool pressedJump;

    public bool releasedJump;

    private bool starTimer = false;

    private float timer;


    private void Awake()
    {
        timer = jumpTimer;
        //initializes the timer
    }

    private void Update()
    {
        MovePlayer();
        ProcessOtherInputs();
        ProcessJump();
        ProcessTimer();
    }

    private void ProcessTimer()
    {
        if (starTimer)
        {
            timer -= Time.deltaTime;
            if (timer <= 0)
            {
                releasedJump = true;
                // Forces the player to release jump if the player has held the jumpbar for a certain amount of time.
            }
        }
    }

    private void ProcessJump()
    {
        if (Input.GetButtonDown("Jump"))
        {
            pressedJump = true;
        }

        if (Input.GetButtonUp("Jump"))
        {
            releasedJump = true;
            // todo I think a better way to do this would be pressedJump = false; and then pass in a parameter
            // but as of right now, this thing works, so we can leave it as is, or whatever.
        }
    }

    private void FixedUpdate()
    {
        if (pressedJump && isGrounded)
        {
            StartJump();
            // Processes the jump process if the player presses space and is touching the ground.
        }

        if (releasedJump)
        {
            StopJump();
            // Stops the jump process whenever the player releases spacebar
        }
    }

    private void StartJump()
    {
        // Lowers the grabity when the player presses the jump button
        rb.gravityScale = 0;
        // The line below actually moves the player
        rb.AddForce(new Vector2(0, verticalSpeed), ForceMode2D.Impulse);
        pressedJump = false;
        starTimer = true;
    }

    private void StopJump()
    {
        // Resets gravity when the player releases the jump button
        rb.gravityScale = gravityScale;
        releasedJump = false;
        timer = jumpTimer;
        // The above line resets the jump timer
        starTimer = false;
    }

    private void ProcessOtherInputs()
    {
        if (Input.GetKeyDown(KeyCode.LeftShift) && !isSprinting )
        {
            // Allows player to sprint if not already sprinting
            sprintMultiplyer = (float)(sprintMultiplyer * 1.5);
            // Changes the sprint multiplyer from 1 to 1.5, allowing the player to move 50% faster.
            isSprinting = true;
        }

        if (Input.GetKeyUp(KeyCode.LeftShift))
        {
            sprintMultiplyer = 1f;
            isSprinting = false;
            //todo check that sprint still works, if not delete isSprinting = false;
        }
    }

    private void MovePlayer()
    {
        // Records player horizontal movement factor, then moves the player
        // Should work for controller?
        Vector3 movement = new Vector3(Input.GetAxis("Horizontal"), 0f, 0f);
        transform.position += movement * sprintMultiplyer * Time.deltaTime * horizontalSpeed;
        // The two line above actually move the player.
    }

    public void DisableJump()
    {  
        isGrounded = false;
        // Disables jump after OnCollisionExit
    }

    public void EnableJump()
    {
        isGrounded = true;
        // Enables jump after OnCollisionEnter
    }

   
        
}

