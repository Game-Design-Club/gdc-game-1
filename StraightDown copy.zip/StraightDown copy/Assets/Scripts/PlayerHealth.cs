﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerHealth : MonoBehaviour
{
    [SerializeField] public float playerHealth; //Real time health
    [SerializeField] Rigidbody2D player;

    private float startHealth;

    public Image healthBar;

    private void Start()
    {
        startHealth = playerHealth;
    }

    private void Update()
    {
        CheckPlayerHealth();
        print(playerHealth); //todo remove later, or now 
    }

    private void CheckPlayerHealth()
    {
        if (playerHealth <= 0)
        {
            print("You is dead");
            //todo add actual death effect
        }
    }

    public void DamagePlayer(float damage) //This is the method on which every enemy will call in order to deel damage to the player
    {
        playerHealth -= damage;
        healthBar.fillAmount = playerHealth / startHealth; //Determines how filled the health bar will be.
    }

}
