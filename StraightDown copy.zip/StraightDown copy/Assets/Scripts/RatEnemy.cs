﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class RatEnemy : MonoBehaviour
{
    public Transform Player; //Remember to drag player gameObject
    public Rigidbody2D rat;  //Remember to drag the rat gameObject

    [SerializeField] float moveSpeed = 4f; //Controls how fast the rat moves once engaged.
    [SerializeField] float minXDist = 20f; //controls how close a player can get before the rat engages.
    [SerializeField] float minYDist = 2f;
    [SerializeField] float rattyXKnockBackForce;
    [SerializeField] float rattyYKnockBackForce;

    public bool engagedLeft;
    public bool engagedRight;
    public bool alreadyTriggered;

    private void Update()
    {
        RunRatDetection(); //Check whether rat should engage
        MoveRat(); //Actually moves the rat once detection determines that the rat should attack
    }

    private void RunRatDetection()
    {
        if (Player.position.x - rat.position.x <= minXDist && Player.position.x - rat.position.x >= -minXDist) // Checks x distance
        {
            if (Player.position.y - rat.position.y <= minYDist && Player.position.y - rat.position.y >= -minYDist) // Checks y distance
            {
                if (Player.position.x < rat.position.x && !alreadyTriggered) //Checks if player is on the left and whether the rat already attacked
                {
                    engagedLeft = true; //Enables the movement for the movement script
                    alreadyTriggered = true; // Disables the rat's ability to change directions once engaged
                }

                if (Player.position.x > rat.position.x && !alreadyTriggered )
                {
                    engagedRight = true; //Enables the movement for the movement script
                    alreadyTriggered = true; // Disables the rat's ability to change directions once engaged
                }
            }
        }
    }

    private void MoveRat()
    {
        if (engagedLeft)
        {
            rat.transform.Translate(Vector2.left * moveSpeed * Time.deltaTime); // Actually moves the rat left
        }

        if (engagedRight)
        {
            rat.transform.Translate(Vector2.right * moveSpeed * Time.deltaTime); // Actually moves the rat right
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.collider.tag == "Player")
        {
            float rattyPosition = rat.transform.position.x - Player.transform.position.x;
            Destroy(gameObject);
            FindObjectOfType<PlayerMovement>().KnockBackPlayer(rattyPosition, rattyXKnockBackForce, rattyYKnockBackForce);
        }

        if (collision.collider.tag == "Untagged")
        {
            Destroy(gameObject); //Destroys the rat
        }
    }
}


//Drone Companion script
/*using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ratEnemy : MonoBehaviour
{
    public Transform Player;

    private float moveSpeed = 4f;
    private float maxDist = 10f;
    private float minDist = 5f;

    private void Update()
    {
        transform.LookAt(Player);

        if (Vector2.Distance(transform.position, Player.position) >= minDist)
        {
            transform.position += transform.forward * moveSpeed * Time.deltaTime;
        }

    }

  
}
*/
