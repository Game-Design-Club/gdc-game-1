﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpikeColliDetect : MonoBehaviour
{
    [SerializeField] float spikeDamage; //How much damage each individual spike will do

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.collider.CompareTag("Player"))
        {
            FindObjectOfType<PlayerHealth>().DamagePlayer(spikeDamage);
        }
    }
}
