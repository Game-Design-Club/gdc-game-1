﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BattyTheBat : MonoBehaviour
{
    public Rigidbody2D battyTheBat;
    public Rigidbody2D player;

    private float verticalDistanceToPlayer; //Variable that changes throughout batty's attck

    [SerializeField] float batVerticalSpeed; //batty's y speed. I suggest a value around 2
    [SerializeField] float batHorizontalSpeed; //batty's x speed. I suggest a value around 20
    [SerializeField] float battyDamage;
    [SerializeField] float battyXKnockBackForce;
    [SerializeField] float battyYKnockBackForce;

    private bool movingRight;
    private bool movingLeft;

    private bool alreadyEngaged; //Whether or not batty already engaged the player in a particular x direction.
    private bool isLevel; //Compares player y and bat y coordinate

    public bool playerSighted;

    private void Update()
    {
        if (playerSighted && player.transform.position.y - battyTheBat.transform.position.y < 0) //Utilizes vision for trigger
        {
            AttackPlayer();
        }

        MoveBatLeft();
        MoveBatRight();
        GetDistanceToPlayer();
    }

    private void AttackPlayer()
    {
        if (player.transform.position.x > battyTheBat.transform.position.x) //Player is to the right
        {
            //Moves batty down until level with the target
            if (!isLevel)
            {
                battyTheBat.transform.Translate(Vector2.down * Time.deltaTime * batVerticalSpeed * verticalDistanceToPlayer);
            }
            

            if (!alreadyEngaged)
            {
                movingRight = true;
                alreadyEngaged = true;
            }
           
        }

        if (player.transform.position.x < battyTheBat.transform.position.x ) //Player is to the right
        {
            //Moves batty down until level with the target
            if (!isLevel)
            {
                battyTheBat.transform.Translate(Vector2.down * Time.deltaTime * batVerticalSpeed * verticalDistanceToPlayer);
            }


            if (!alreadyEngaged)
            {
                movingLeft = true;
                alreadyEngaged = true;
            }
        }
    }

    private void GetDistanceToPlayer()
    {
        //Determines the vertical distance between batty and the player in order to determine the stopping point
        verticalDistanceToPlayer = battyTheBat.transform.position.y - player.transform.position.y;
        if (verticalDistanceToPlayer < Mathf.Epsilon)
        {
            isLevel = true;
        }
    }

    private void MoveBatRight()
    {
        if (movingRight)
        {
            //Moves batty right once engaged, irriversible until death.
            battyTheBat.transform.Translate(Vector2.right * batHorizontalSpeed * Time.deltaTime);
        }
    }

    private void MoveBatLeft()
    {
        if (movingLeft)
        {
            //Moves batty left once engaged, irriversible until death.
            battyTheBat.transform.Translate(Vector2.left * batHorizontalSpeed * Time.deltaTime);
        }
    }


    private void OnCollisionEnter2D(Collision2D collision) //Determnes what happens when batty hits something
                                                           
    {
        if (collision.collider.tag == "Player")
        {
            float battyLocation = battyTheBat.transform.position.x - player.transform.position.x;
            FindObjectOfType<PlayerHealth>().DamagePlayer(battyDamage);
            FindObjectOfType<PlayerMovement>().KnockBackPlayer(battyLocation, battyXKnockBackForce, battyYKnockBackForce);
            Destroy(gameObject);
            
        }

        if (collision.collider.tag == "Untagged")
        {
            Destroy(gameObject);
        }

        if (collision.collider.tag == "Ground")
        {
            Destroy(gameObject);
        }

        if (collision.collider.tag == "Death")
        {
            Destroy(gameObject);
        }
    }


}
